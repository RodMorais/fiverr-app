module.exports = `
loginMutation(
    password: String!,
    email: String!,
): Users
`