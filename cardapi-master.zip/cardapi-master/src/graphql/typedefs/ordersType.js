module.exports = `
    type Orders {
        totalAmount: Float,
        userId: String,
        productId: String,
        Address: String,
        status: String,
        storeId: String
    }
`
//TODO productId is supposed to be an array