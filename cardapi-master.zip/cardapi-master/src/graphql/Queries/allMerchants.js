module.exports = `
    allMerchants: [Merchant]
    getMerchant(id: String): Merchant
`