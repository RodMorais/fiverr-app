module.exports = `
    allProducts: [Products]
    getProduct(id: String): Products
    getProductByCatalogue(storeId: String): [Products]
`