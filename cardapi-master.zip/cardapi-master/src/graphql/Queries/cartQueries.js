module.exports = `
    allCarts: [Cart]
    getCart(id: String): Cart
`